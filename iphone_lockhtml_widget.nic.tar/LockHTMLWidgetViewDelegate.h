//
//  LockHTMLWidgetViewDelegate.h
//  LockHTML
//
//  Created by Ryan Bushe.
//  Copyright © 2017 Bushe. All rights reserved.
//

@protocol LockHTMLWidgetViewDelegate
//@required
//-(UIView*)view;
@optional
-(void)prepareWidgetForNotificationsWithContent:(BOOL)hasContent;
-(void)handleMenuButtonTap;
-(void)updateWidgetForScreenStatus:(BOOL)status;
@end